<script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/04f46c6a/qrcode.min.js"></script>
<script src="https://unpkg.com/global-input-message@1.5.5/distribution/globalinputmessage.min.js"></script>